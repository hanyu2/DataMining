For problem1, go to Multi Label Scene Data folder, run multilabel.m.
For problem2, go to Handwritten Digits folder, run handwritten.m